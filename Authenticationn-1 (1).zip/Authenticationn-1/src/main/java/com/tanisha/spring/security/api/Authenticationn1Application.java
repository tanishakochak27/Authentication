package com.tanisha.spring.security.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Authenticationn1Application {

	public static void main(String[] args) {
		SpringApplication.run(Authenticationn1Application.class, args);
	}

}
