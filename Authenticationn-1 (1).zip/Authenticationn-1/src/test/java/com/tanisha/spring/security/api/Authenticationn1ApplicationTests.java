package com.tanisha.spring.security.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Authenticationn1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
